File	Description	Date retrieved	Source
HPO_phenotype_to_genes.txt	HPO association between gene and phenotypes, latest version	09JUN2021	http://purl.obolibrary.org/obo/hp/hpoa/phenotype_to_genes.txt
phenotype_annotation.tab	A cached version of HPO-gene association before 2018	15JUN2021	http://purl.obolibrary.org/obo/hp/hpoa/phenotype_annotation.tab	